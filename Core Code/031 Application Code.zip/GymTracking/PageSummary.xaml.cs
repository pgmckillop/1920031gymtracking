﻿using System.Windows;
using System.Windows.Controls;

/*
 * Title:   Code behind GUI
 * Author:  Paul McKillop
 * Date:    03 January 2020
 * Purpose: Present data on the SummaryPage interface
 */

namespace GymTracking
{
    /// <summary>
    /// Interaction logic for PageSummary.xaml
    /// </summary>
    public partial class PageSummary : Page
    {
        //-- Handler object
        Summary summary = new Summary();
        public PageSummary(Summary summaryPassed)
        {
            InitializeComponent();

            //-- Assign the data to the object
            summary = summaryPassed;

            //-- Use intermediary variables for redability
            string person = summary.SessionPerson.PersonName;
            string numberOfActivities = summary.NumberOfActivities.ToString();
            string minutesOfExercise = summary.MinutesOfExercise.ToString();
            string totalUsed = summary.TotalUsed.ToString();
            

            //-- Populate the information controls
            PersonTextBlock.Text = person;

            NumberActitiesTextBlock.Text = "Number of Activites: " + numberOfActivities;

            MinutesExerciseTextBlock.Text = "Minutes of Exercise: " + minutesOfExercise;

            TotalUsedTextBlock.Text = totalUsed;
        }

        
            //-- Back to activity page
        private void SummaryPageBackButton_Click(object sender, RoutedEventArgs e)
        {
            var pageActivity = new PageActivity();
            this.NavigationService.Navigate(pageActivity);
        }

        //-- Close the application down completely
        private void SummaryPageExitButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
