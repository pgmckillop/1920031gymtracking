# Gym Charges

031 1920 mimic application.

Replacment structure to teach the concepts and skills reuired for the synoptic application, coversion to scenario at end of training.
